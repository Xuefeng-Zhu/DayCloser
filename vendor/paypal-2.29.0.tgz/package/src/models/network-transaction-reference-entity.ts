import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import { cardBrandSchema, type CardBrand } from "./card-brand.js";

/** Previous network transaction reference including id and network. */
export type NetworkTransactionReferenceEntity = {
  /**
   * Transaction reference id returned by the scheme. For Visa and Amex, this is the "Tran id" field
   * in response. For MasterCard, this is the "BankNet reference id" field in response. For
   * Discover, this is the "NRID" field in response. The pattern we expect for this field from
   * Visa/Amex/CB/Discover is numeric, Mastercard/BNPP is alphanumeric and Paysecure is alphanumeric
   * with special character -.
   */
  id: string;
  /**
   * The date that the transaction was authorized by the scheme. This field may not be returned for
   * all networks. MasterCard refers to this field as "BankNet reference date.
   */
  date?: string;
  /** The card network or brand. Applies to credit, debit, gift, and payment cards. */
  network?: CardBrand;
  /**
   * The date and time, in [Internet date and time
   * format](https://tools.ietf.org/html/rfc3339#section-5.6). Seconds are required while fractional
   * seconds are optional. Note: The regular expression provides guidance but does not reject all
   * invalid dates.
   */
  time?: string;
};

export const networkTransactionReferenceEntitySchema: Schema<NetworkTransactionReferenceEntity> =
  s.object<NetworkTransactionReferenceEntity>({
    id: s.string(),
    date: s.optional(s.string()),
    network: s.optional(s.lazy(() => cardBrandSchema)),
    time: s.optional(s.string()),
  });
