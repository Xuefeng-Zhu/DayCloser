import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";

/** Information needed to pay using Trustly. */
export type TrustlyPaymentObject = {
  /** The full name representation like Mr J Smith. */
  name?: string;
  /**
   * The [two-character ISO 3166-1
   * code](https://developer.paypal.com/api/rest/reference/country-codes/) that identifies the
   * country or region. Note: The country code for Great Britain is GB and not UK as used in the
   * top-level domain names for that country. Use the `C2` country code for China worldwide for
   * comparable uncontrolled price (CUP) method, bank card, and cross-border transactions.
   */
  countryCode?: string;
  /**
   * The internationalized email address. Note: Up to 64 characters are allowed before and 255
   * characters are allowed after the \@ sign. However, the generally accepted maximum length for an
   * email address is 254 characters. The pattern verifies that an unquoted \@ sign exists.
   */
  email?: string;
  /**
   * The business identification code (BIC). In payments systems, a BIC is used to identify a
   * specific business, most commonly a bank.
   */
  bic?: string;
  /** The last characters of the IBAN used to pay. */
  ibanLastChars?: string;
};

export const trustlyPaymentObjectSchema: Schema<TrustlyPaymentObject> = s.object<TrustlyPaymentObject>({
  name: s.optional(s.string()),
  countryCode: s.optional(s.string()),
  email: s.optional(s.string()),
  bic: s.optional(s.string()),
  ibanLastChars: s.optional(s.string()),
  _keysMap: {
    countryCode: "country_code",
    ibanLastChars: "iban_last_chars",
  },
});
