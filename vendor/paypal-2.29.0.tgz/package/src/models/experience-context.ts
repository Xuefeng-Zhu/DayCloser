import * as s from "../core/validation/index.js";
import type { Schema } from "../core/validation/schema.js";
import {
  ExperienceContextShippingPreference,
  experienceContextShippingPreferenceSchema,
} from "./experience-context-shipping-preference.js";

/** Customizes the payer experience during the approval process for the payment. */
export type ExperienceContext = {
  /**
   * The label that overrides the business name in the PayPal account on the PayPal site. The
   * pattern is defined by an external party and supports Unicode.
   */
  brandName?: string;
  /**
   * The [language tag](https://tools.ietf.org/html/bcp47#section-2) for the language in which to
   * localize the error-related strings, such as messages, issues, and suggested actions. The tag is
   * made up of the [ISO 639-2 language
   * code](https://www.loc.gov/standards/iso639-2/php/code_list.php), the optional [ISO-15924 script
   * tag](https://www.unicode.org/iso15924/codelists.html), and the [ISO-3166 alpha-2 country
   * code](https://developer.paypal.com/api/rest/reference/country-codes/) or [M49 region
   * code](https://unstats.un.org/unsd/methodology/m49/).
   */
  locale?: string;
  /**
   * The location from which the shipping address is derived.
   *
   * @default ExperienceContextShippingPreference.GetFromFile
   */
  shippingPreference?: ExperienceContextShippingPreference;
  /** Describes the URL. */
  returnUrl?: string;
  /** Describes the URL. */
  cancelUrl?: string;
};

export const experienceContextSchema: Schema<ExperienceContext> = s.object<ExperienceContext>({
  brandName: s.optional(s.string()),
  locale: s.optional(s.string()),
  shippingPreference: s.defaulted(
    experienceContextShippingPreferenceSchema,
    ExperienceContextShippingPreference.GetFromFile,
  ),
  returnUrl: s.optional(s.string()),
  cancelUrl: s.optional(s.string()),
  _keysMap: {
    brandName: "brand_name",
    shippingPreference: "shipping_preference",
    returnUrl: "return_url",
    cancelUrl: "cancel_url",
  },
});
